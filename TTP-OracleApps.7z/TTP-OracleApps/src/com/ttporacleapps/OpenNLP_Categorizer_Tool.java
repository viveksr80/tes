package com.ttporacleapps;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

public class OpenNLP_Categorizer_Tool {
		
	public static void main(String[] args) throws InterruptedException,
			IOException {
		OpenNLP_Categorizer_Tool oct = new OpenNLP_Categorizer_Tool();
		oct.getActionsList("CaseReviewLoanstatus");
	}

	public  ArrayList<String> getActionsList(String TestCase){
		ArrayList<String> Output = null;
		try {
			//String cmd = "c cd C:/OpenNLP/apache-opennlp-1.8.0/bin & opennlp Doccat en-doccat.bin <input.txt & exit"; 
			String cmd = "/c cd C:/OpenNLP/apache-opennlp-1.8.0/bin & opennlp Doccat en-doccat.bin <"+ TestCase +".txt & exit";
			
			ProcessBuilder pb = new ProcessBuilder("cmd.exe", cmd);
			//System.out.println("Run echo command");
			Process process = pb.start();
			//int errCode = process.waitFor();
			//System.out.println("Echo command executed, any errors? " + (errCode == 0 ? "No" : "Yes"));
			Output = output(process.getInputStream());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Output;		
	}
	
	public  ArrayList<String> output(InputStream inputStream) throws IOException {
		StringBuilder sb = new StringBuilder();
		BufferedReader br = null;
		ArrayList<String> ActionsList = new ArrayList<String>();
		try {
			br = new BufferedReader(new InputStreamReader(inputStream));
			String line = null;
			
			while ((line = br.readLine()) != null) {
				String[] MyArr = line.split("\t");
				if (MyArr.length==2){
					System.out.println("Action : " + MyArr[0].toString() + " | " + "Sentence : " + MyArr[1].toString());
					sb.append(line + System.getProperty("line.separator"));
					ActionsList.add(MyArr[0].toString() + " | " + MyArr[1].toString());
				}
//				System.out.println("Sentence : " + MyArr[1].toString());

				}

				
			
		} finally {
			br.close();
		}
		return ActionsList;
	}
}