package com.ttporacleapps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.Properties;

public class TextFileHandler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//WriteToFile("SomeText");
//		ClearFileContents();
//		CreateTextFile("C:/Srinath/Softwares/apache-opennlp-1.8.0/bin", "Create_and_Approve_Purchase_Order");
	}

	public static void WriteToFile(String TextFilePath, String txtLine){
		try {
			FileWriter write = new FileWriter(TextFilePath, true);
			PrintWriter print_line = new PrintWriter(write);
			
			print_line.printf("%s"+"%n", txtLine);
			print_line.printf("%n", "");
			
			print_line.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void WriteToFile1(String TextFilePath, List<String> output){
		try {
			FileWriter write = new FileWriter(TextFilePath, true);
			PrintWriter print_line = new PrintWriter(write);
			
			print_line.printf("%s"+"%n", output);
			print_line.printf("%n", "");
			
			print_line.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
/*	public static void ClearFileContents(){
		try {
			FileWriter write = new FileWriter("C:/Srinath/Softwares/apache-opennlp-1.8.0/bin/input1.txt", false);
			PrintWriter print_line = new PrintWriter(write);
			
			print_line.printf("");			
			print_line.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	public static void CreateTextFile(String txtFilePath, String txtFileName){
		try {

		      File file = new File(txtFilePath+"/"+txtFileName+".txt");

		      if (file.createNewFile()){
		        System.out.println("File is created!");
		      }else{
		        System.out.println("File already exists.");
		      }

	    	} catch (IOException e) {
		      e.printStackTrace();
		}
	}
	
	public static void DeleteTextFile(String txtFilePath, String txtFileName){
		try {

		      File file = new File(txtFilePath+"/"+txtFileName+".txt");

		      if (file.delete()){
		        System.out.println("File is deleted!");
		      }else{
		        System.out.println("File already deleted.");
		      }

	    	} catch (Exception e) {
		      e.printStackTrace();
		}
	}
	
public static String CreateRunnerClassFile(String TestCaseName){
        
        try {
               Properties config = new Properties();
          InputStream input = new FileInputStream("config.properties");
               config.load(input);
               
               String RunnerClassFilePath = config.getProperty("RunnerClassFilePath");
               String TestScriptName = TestCaseName.replaceAll(" ", "");

              File file = new File(RunnerClassFilePath+"/"+"ExecuteScript"+TestScriptName+".java");
              
              if (file.createNewFile()){
                System.out.println("File is created!");
              }else{
                System.out.println("File already exists.");
              }

                      FileWriter write = new FileWriter(file, false);
                      PrintWriter print_line = new PrintWriter(write);
                      
                      //Runner Script Template
                      print_line.printf("%s"+"%n", "package com.accenture.runner.selenium;");
                      print_line.printf("%n", "");
                      
                      print_line.printf("%s"+"%n", "import org.junit.Test;");
                      print_line.printf("%s"+"%n", "import com.accenture.runner.utility.ExecuteScriptRunner;");
                      print_line.printf("%n", "");
                      print_line.printf("%n", "");
                      
                      print_line.printf("%s"+"%n", "/**");
                      print_line.printf("%s"+"%n", "* Class is used for selenium test");
                      print_line.printf("%s"+"%n", "* ");
                      print_line.printf("%s"+"%n", "* @author      ");
                      print_line.printf("%s"+"%n", "* @version     1.0");
                      print_line.printf("%s"+"%n", "*/");
                      
                      print_line.printf("%n", "");
                      print_line.printf("%n", "");
                      
                      print_line.printf("%s"+"%n", "public class ExecuteScript"+TestScriptName+" extends ExecuteScriptRunner{");
                      print_line.printf("%s"+"%n", "   public ExecuteScript"+TestScriptName+"() {");
                      print_line.printf("%s"+"%n", "          super(\"" + TestCaseName+"\""+", \"com.accenture.runner.selenium.ExecuteScript"+TestScriptName+"\", \"local"+"\");");
                      print_line.printf("%s"+"%n", "   }");
                      print_line.printf("%s"+"%n", "   /**");
                      print_line.printf("%s"+"%n", "   * Method is used to execute script");
                      print_line.printf("%s"+"%n", "   *");
                      print_line.printf("%s"+"%n", "   */");
                      print_line.printf("%s"+"%n", "   @Test");
                      print_line.printf("%s"+"%n", "   public void test() {");
                      print_line.printf("%s"+"%n", "          executeTest();");
                      print_line.printf("%s"+"%n", "   }");
                      print_line.printf("%s"+"%n", "}");
                      
                      print_line.close();
              
         } catch (IOException e) {
              e.printStackTrace();
        }
		return TestCaseName;
		
        
  }
	
}
