package com.ttporacleapps;

import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import com.excelreadwrite.ExcelReadWrite;
import com.propertyreader.PropertyFileReader;

public class CoreScriptRunner {

	static ExcelReadWrite excelReader = null;

	public static void main(String[] args) {
		try {

			OpenNLP_Categorizer_Tool MyActionList = new OpenNLP_Categorizer_Tool();

			// Generate the Input Text File
			ExcelHandler generateActionsInputFile = new ExcelHandler();
			ArrayList<String> TestCaseList = generateActionsInputFile.getTestCases();

			for (String TestCase : TestCaseList) {

				System.out.println("====================================");
				System.out.println("Executing Test Case : " + TestCase);
				generateActionsInputFile.getTestStepsInputSheet(TestCase.replaceAll("_", " "));

				// Using OpenNLP, parse the Test steps Input Sheet and find
				// corresponding Major Action
				ArrayList<String> ActionList = MyActionList.getActionsList(TestCase.replaceAll(" ", "_"));
				SubactionWriter GetSubAction = new SubactionWriter();

				// Create Test Script File using Standard Template
				ExcelReadWrite excelReader = new ExcelReadWrite();
				PropertyFileReader propertyFileReader = new PropertyFileReader();

				String testCaseName = TestCase.replaceAll("_", " ");
				String source1 = propertyFileReader.getValue("KeywordTemplate");
				String SourceTemplate = propertyFileReader.getValue("SourceTemplate");
				String dest1 = propertyFileReader.getValue("KeywordScript") + testCaseName + ".xls";

				// To copy Keyword template
				excelReader.copyTemplate(source1, dest1);

				// Adding sheet data into array
				List sheetData = new ArrayList();

				for (String Action : ActionList) {

					// Write Keyword Specific template action
					sheetData = excelReader.readExcel(SourceTemplate, Action);
					excelReader.writetarget(dest1, sheetData);

				}

				// Create Runner Class in required destination path
				TextFileHandler.CreateRunnerClassFile(testCaseName);
			}

			// To update SeleniumRunner-repo.xls file
			String[] runnerClassName = { TestCaseList.get(0).replaceAll("_", ""),
					TestCaseList.get(1).replaceAll("_", "") };
			ExcelReadWrite.updateRO(runnerClassName);

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public static void ExecuteMethod(String MethodName, HashMap<String, String> MyHash) {

		Class[] dataparams = new Class[1];
		dataparams[0] = HashMap.class;

		Properties config = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("config.properties");
			config.load(input);

			config.get("ClassesToParse");
		} catch (Exception e) {

			e.printStackTrace();
		}

		// Array List of all Class files to be scanned for Methods
		String[] MyClasses = config.get("ClassesToParse").toString().split(",");

		for (int x = 0; x <= MyClasses.length - 1; x++) {

			try {

				// load the BusinessComponents at runtime

				Class cls = Class.forName("com.ttporacleapps." + MyClasses[x].toString());
				Object obj = cls.newInstance();
				Method method;

				// call the method dynamically based on input Method Name and
				// dataparams key value pair
				method = cls.getDeclaredMethod(MethodName, dataparams);
				method.invoke(obj, MyHash);
				break;

			} catch (Exception ex) {

				if (ex.toString().contains("NoSuchMethodException")) {
					if (x == (MyClasses.length - 1)) {
						System.out.println("Method : " + MethodName
								+ " was not found in any of the Class Files. Please check whether the Method/ Action Name is spelled in right way");
					} else {
						continue; // Continue looping through other class files,
									// if Method is not found in a particular
									// class file
					}
				}
			}

		}
	}

} // End of Class