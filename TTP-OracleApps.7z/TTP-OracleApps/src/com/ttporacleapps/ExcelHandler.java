package com.ttporacleapps;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;



public class ExcelHandler {

	static Properties config = new Properties();


    
    public static void main(String[] args) {
    	
//    	getTestStepsInputSheet("Cancel Purchase Order");
//    	System.out.println(getTestCases());
 
    }
    
    public static void getTestStepsInputSheet(String TestCaseName){
    	
        
		try {
	    	ArrayList columndata = null;
	        String TestCaseNameFetched = "", RunningTestCaseName = "";
	        int columnIndex, startRow, TestCaseColNum;
	        
	        InputStream input = new FileInputStream("config.properties");
			config.load(input);
			
			String TextFilePath = (String) config.get("TextFilePath");
	        columnIndex =  Integer.parseInt(config.get("columnIndex").toString());
	        startRow =  Integer.parseInt(config.get("startRow").toString());
	        TestCaseColNum =  Integer.parseInt(config.get("TestCaseColNum").toString());
	    	String TestCaseExcelFile = config.get("TestCaseExcelFile").toString();
	        
	        TextFileHandler TextFileWriter = new TextFileHandler();
	        //Clear File Contents before inserting Test Steps

//	        TextFileWriter.ClearFileContents();
	        TextFileWriter.DeleteTextFile(TextFilePath, TestCaseName.replaceAll(" ", "_"));
	        TextFileWriter.CreateTextFile(TextFilePath, TestCaseName.replaceAll(" ", "_"));

			
            File f = new File(TestCaseExcelFile);
            FileInputStream ios = new FileInputStream(f);
            HSSFWorkbook workbook = new HSSFWorkbook(ios);
            HSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            columndata = new ArrayList<>();
            boolean TestCaseStart = false;

            
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    if (cell.getColumnIndex() == TestCaseColNum) {
                    	String TC_Name = TestCaseName;
                    	if (cell.getStringCellValue().equalsIgnoreCase(TC_Name)){
                    		TestCaseStart = true;
                    		TestCaseNameFetched = cell.getStringCellValue();
                    	}
                    	
                    	RunningTestCaseName = cell.getStringCellValue();
                    }
                    
//                    if (TestCaseStart=true | TestCaseNameFetched == "Create and Approve Purchase Order" | TestCaseNameFetched != ""){
		                    if(row.getRowNum() >= startRow){ //To filter column headings
		                    	
								if(cell.getColumnIndex() == columnIndex){// To match Test Step column index
		                            switch (cell.getCellType()) {
		                            case Cell.CELL_TYPE_NUMERIC:
		                                columndata.add(cell.getNumericCellValue()+"");
		                                break;
		                            case Cell.CELL_TYPE_STRING:
				                    	CellReference cr = new CellReference("B"+row.getRowNum());
				                    	
/*				                    	Row row1 = sheet.getRow(cr.getRow());
				                    	Cell cell1 = row1.getCell(cr.getCol());
*/				                    	//System.out.println(RunningTestCaseName);
/*					                    	if (cell1.getStringCellValue().equalsIgnoreCase("Create and Approve Purchase Order")) {
					                    		TestCaseStart = true;
					                    	}
*/
					                    	if (!RunningTestCaseName.equalsIgnoreCase("")) {
					                    		if (!RunningTestCaseName.equalsIgnoreCase(TestCaseName)){
					                    			TestCaseStart = false;
					                    		}
					                    	}
					                    	
					                    	
					                    	if (TestCaseStart) {
					                    		TextFileWriter.WriteToFile(TextFilePath+"/"+TestCaseName.replaceAll(" ", "_")+".txt", cell.getStringCellValue());    	
					                    		columndata.add(cell.getStringCellValue());
				                                break;
					                    	} else {
					                    		break;
					                    	}
					                    	

		                            }
		                        }
//		                    }
                    }
                }
            }
            ios.close();
            TestCaseStart=false;
            //System.out.println(columndata);
        } catch (Exception e) {
            e.printStackTrace();
        }
//        return columndata;
    }
    
    public static ArrayList<String> getTestCases(){
        ArrayList TestCases = null;
        
		try {
	        int columnIndex, startRow, TestCaseColNum;

	        
	        InputStream input = new FileInputStream("config.properties");
			config.load(input);
			
			String TextFilePath = (String) config.get("TextFilePath");
	        columnIndex =  Integer.parseInt(config.get("columnIndex").toString());
	        startRow =  Integer.parseInt(config.get("startRow").toString());
	        TestCaseColNum =  Integer.parseInt(config.get("TestCaseColNum").toString());
	    	String TestCaseExcelFile = config.get("TestCaseExcelFile").toString();
	        
            File f = new File(TestCaseExcelFile);
            FileInputStream ios = new FileInputStream(f);
            HSSFWorkbook workbook = new HSSFWorkbook(ios);
            HSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            TestCases = new ArrayList<>();

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    if(row.getRowNum() >= startRow){ //To filter column headings
						if(cell.getColumnIndex() == TestCaseColNum){// To match Test Step column index
                            switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_NUMERIC:
                            	TestCases.add(cell.getNumericCellValue()+"");
                                break;
                            case Cell.CELL_TYPE_STRING:    	
                            	if (!cell.getStringCellValue().equalsIgnoreCase("")){
                            		cell.getStringCellValue().trim();
                            		TestCases.add(cell.getStringCellValue().replaceAll(" ", "_"));
                            		break;
                            	}
                            }
                        }
                    }
                }
            }
            ios.close();
//            System.out.println(TestCases);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return TestCases;
    }
    
}// End of Class