package com.ttporacleapps;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SubactionWriter {
	
	public static int a_loc = 0;
	
	public String fetchSubActionData(String action) throws IOException {

		String filename = "data1.xls";
		String subaction = null;

		List<List<HSSFCell>> sheetData = new ArrayList<List<HSSFCell>>();

		FileInputStream fis = null;
		try {

			fis = new FileInputStream(filename);

			HSSFWorkbook workbook = new HSSFWorkbook(fis);

			HSSFSheet sheet = workbook.getSheetAt(0);

			Iterator<Row> rows = sheet.rowIterator();
			
			while (rows.hasNext()) {
				HSSFRow row = (HSSFRow) rows.next();
				Iterator<Cell> cells = row.cellIterator();
				List<HSSFCell> data = new ArrayList<HSSFCell>();
				
				while (cells.hasNext()) {
					HSSFCell cell = (HSSFCell) cells.next();
					data.add(cell);
				}

				sheetData.add(data);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				fis.close();
			}
		}

		// Location of maindata in list
		for (int i = 0; i < sheetData.size(); i++) {

			List<?> list = (List<?>) sheetData.get(i);
			// System.out.println(" i "+i);

			for (int j = 0; j < list.size(); j++) {

				// covert list obj to cell and cell to string
				HSSFCell cell = (HSSFCell) list.get(j);
				String xaction = cell.getRichStringCellValue().getString();

				// System.out.println(" ' "+xaction);

				if (xaction.equalsIgnoreCase("Main Action")) {
					// System.out.println(" : "+j+" "+list.get(j));
					a_loc = j;

				}

				if (a_loc == j) {
					if (action.equalsIgnoreCase(xaction)) {
						System.out.println("Action :" + action + "\nSub Action : " + list.get(j + 1));
						HSSFCell cellsub = (HSSFCell) list.get(j + 1);
						subaction = cellsub.getRichStringCellValue().getString();
					}
				}

			}

			// System.out.println("");
		}
		System.out.println(" return string\t" + subaction);
		return subaction;
	}

	public String[] subAction_Separator(String str) {
		System.out.println("\n\n****************\nin subAction Separator\t" + str);

		String[] splitString = str.split(";");

		for (int i = 0; i < splitString.length; i++)
			System.out.println("splitString[" + i + "] is " + splitString[i]);

		return splitString;
	}

	public void writeSubAction(String str[]) throws IOException {
		System.out.println("\n\n****************\nIn writeSubAction\t");
		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet spreadsheet = workbook.createSheet("cell types");
			XSSFRow row = spreadsheet.createRow((short) 3);

			for (int i = 0; i < str.length; i++) {
				row.createCell(i).setCellValue(str[i]);
			}

			FileOutputStream out = new FileOutputStream("book1.xlsx");
			workbook.write(out);
			out.close();
			System.out.println("Properties added to sheet");

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
