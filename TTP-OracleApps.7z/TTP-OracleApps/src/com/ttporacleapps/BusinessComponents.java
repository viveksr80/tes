package com.ttporacleapps;

import java.util.HashMap;

public class BusinessComponents{

	public void Login(HashMap<String, String> temp){
		System.out.println("Executing Login Method");
	}

	public void CreatePurchaseOrder(HashMap<String, String> temp){
		//Login
		//Navigate to xyz screen
		
		System.out.println("Executing CreatePurchaseOrder Method");
	}

	public void FillTermsTabsDetails(HashMap<String, String> temp){
		System.out.println("Executing FillTermsTabsDetails Method");
	}

	public void AddActions(HashMap<String, String> temp){
		System.out.println("Executing AddActions Method");
	}

	public void AddSchedules(HashMap<String, String> temp){
		System.out.println("Executing AddSchedules Method");
	}

	public void SubmitAction(HashMap<String, String> temp){
		System.out.println("Executing SubmitAction Method");
	}

	public void HandleConfirmationMessage(HashMap<String, String> temp){
		System.out.println("Executing HandleConfirmationMessage Method");
	}

	public void ManageOrderSearch(HashMap<String, String> temp){
		System.out.println("Executing ManageOrderSearch Method");
	}
	
	public void OpenNotifications(HashMap<String, String> temp){
		System.out.println("Executing OpenNotifications Method");
	}

	public void ReviewAndApprovePODetails(HashMap<String, String> temp){
		System.out.println("Executing ReviewAndApprovePODetails Method");
	}
	
	public void CreateAndApprovePurchaseOrder(HashMap<String, String> temp){
		System.out.println("Executing CreateAndApprovePurchaseOrder Method");
	}	

	public void CancelPurchaseOrder(HashMap<String, String> temp){
		System.out.println("Executing CancelPurchaseOrder Method");
	}

	public void HandleCancelPurchaseOrderConfirmationMessage(HashMap<String, String> temp){
		System.out.println("Executing HandleCancelPurchaseOrderConfirmationMessage Method");
	}

	public void HandleCancelPurchaseOrderConfirmationMessage2(HashMap<String, String> temp){
		System.out.println("Executing HandleCancelPurchaseOrderConfirmationMessage2 Method");
	}

	public void PurchaseOrderStatusReview(HashMap<String, String> temp){
		System.out.println("Executing PurchaseOrderStatusReview Method");
	}
	
}