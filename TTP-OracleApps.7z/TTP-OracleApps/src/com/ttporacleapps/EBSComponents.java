package com.ttporacleapps;

import java.util.HashMap;

public class EBSComponents{

	public void EBSGLWEBADIAccessCheck(HashMap<String, String> temp){
		System.out.println("Executing EBSGLWEBADIAccessCheck Method");
	}

	public void EBSLogin(HashMap<String, String> temp){
		System.out.println("Executing EBSLogin Method");
	}

	public void EBSChangeResponsibility(HashMap<String, String> temp){
		System.out.println("Executing EBSChangeResponsibility Method");
	}

	public void EBSOpenLaunchJournalWizard(HashMap<String, String> temp){
		System.out.println("Executing EBSOpenLaunchJournalWizard Method");
	}

	public void EBSSelectLayout(HashMap<String, String> temp){
		System.out.println("Executing EBSSelectLayout Method");
	}

	public void EBSCreateDocument(HashMap<String, String> temp){
		System.out.println("Executing EBSCreateDocument Method");
	}

	public void EBSWEBADISaveDocument(HashMap<String, String> temp){
		System.out.println("Executing EBSWEBADISaveDocument Method");
	}

	public void EBSWEBADIOpenDownloadedExcel(HashMap<String, String> temp){
		System.out.println("Executing EBSWEBADIOpenDownloadedExcel Method");
	}

	public void EBSWEBADIEnterJournalDetails(HashMap<String, String> temp){
		System.out.println("Executing EBSWEBADIEnterJournalDetails Method");
	}

	public void EBSWEBADIEnterLineDetails(HashMap<String, String> temp){
		System.out.println("Executing EBSWEBADIEnterLineDetails Method");
	}

	public void EBSClickSelectButton(HashMap<String, String> temp){
		System.out.println("Executing EBSClickSelectButton Method");
	}

	public void EBSEnterDebitLineDetails(HashMap<String, String> temp){
		System.out.println("Executing EBSEnterDebitLineDetails Method");
	}

	public void EBSEnterCreditLevelTransactionDetails(HashMap<String, String> temp){
		System.out.println("Executing EBSEnterCreditLevelTransactionDetails Method");
	}

	public void EBSEnterCreditLineDetails(HashMap<String, String> temp){
		System.out.println("Executing EBSEnterCreditLineDetails Method");
	}

	public void EBSTollbarUpload(HashMap<String, String> temp){
		System.out.println("Executing EBSTollbarUpload Method");
	}

	public void EBSUploadImportWithValidation(HashMap<String, String> temp){
		System.out.println("Executing EBSUploadImportWithValidation Method");
	}

	public void EBSValidateJournalCreation(HashMap<String, String> temp){
		System.out.println("Executing EBSValidateJournalCreation Method");
	}

	public void EBSOpenJournalsWindow(HashMap<String, String> temp){
		System.out.println("Executing EBSOpenJournalsWindow Method");
	}

	public void EBSJournalSearch(HashMap<String, String> temp){
		System.out.println("Executing EBSJournalSearch Method");
	}

	public void EBSWEBADIJournalValidate(HashMap<String, String> temp){
		System.out.println("Executing EBSWEBADIJournalValidate Method");
	}

	public void EBSLogout(HashMap<String, String> temp){
		System.out.println("Executing EBSLogout Method");
	}

	public void EBSSelectResponsibility(HashMap<String, String> temp){
		System.out.println("Executing EBSSelectResponsibility Method");
	}

	public void EBSJournalCreateWithAppropriateReversalPeriod(HashMap<String, String> temp){
		System.out.println("Executing EBSJournalCreateWithAppropriateReversalPeriod Method");
	}

	public void EBSChangeResponsibilityGLUSManager(HashMap<String, String> temp){
		System.out.println("Executing EBSChangeResponsibilityGLUSManager Method");
	}

	public void EBSOpenFindRequestWindow(HashMap<String, String> temp){
		System.out.println("Executing EBSOpenFindRequestWindow Method");
	}

	public void EBSCreateNewRequest(HashMap<String, String> temp){
		System.out.println("Executing EBSCreateNewRequest Method");
	}

	public void EBSEnterSubmitNewRequestNameOpenParameterWindow(HashMap<String, String> temp){
		System.out.println("Executing EBSEnterSubmitNewRequestNameOpenParameterWindow Method");
	}

	public void EBSEnterDetailsParameterWindow(HashMap<String, String> temp){
		System.out.println("Executing EBSEnterDetailsParameterWindow Method");
	}

	public void EBSParameterWindowHandleNoButton(HashMap<String, String> temp){
		System.out.println("Executing EBSParameterWindowHandleNoButton Method");
	}

	public void EBSParameterWindowHandleFindButton(HashMap<String, String> temp){
		System.out.println("Executing EBSParameterWindowHandleFindButton Method");
	}

	public void EBSValidateRequestStatus(HashMap<String, String> temp){
		System.out.println("Executing EBSValidateRequestStatus Method");
	}

	public void EBSRequestOutputValidate(HashMap<String, String> temp){
		System.out.println("Executing EBSRequestOutputValidate Method");
	}

	public void EBSValidateCalendarSetup(HashMap<String, String> temp){
		System.out.println("Executing EBSValidateCalendarSetup Method");
	}

	public void EBSChooseGLGlobal12PeriodCloseResponsibility(HashMap<String, String> temp){
		System.out.println("Executing EBSChooseGLGlobal12PeriodCloseResponsibility Method");
	}

	public void EBSOpenFindPeriodsWindow(HashMap<String, String> temp){
		System.out.println("Executing EBSOpenFindPeriodsWindow Method");
	}

	public void EBSEnterFindPeriodsWindowDetails(HashMap<String, String> temp){
		System.out.println("Executing EBSEnterFindPeriodsWindowDetails Method");
	}

	public void EBSOpenNextPeriod(HashMap<String, String> temp){
		System.out.println("Executing EBSOpenNextPeriod Method");
	}

	public void PurchaseSelectCatalogandItem(HashMap<String, String> temp){
		System.out.println("Executing PurchaseSelectCatalogandItem Method");
	}

	public void PurchaseSelectCatalog(HashMap<String, String> temp){
		System.out.println("Executing PurchaseSelectCatalog Method");
	}

	public void PurchaseAddToRequisition(HashMap<String, String> temp){
		System.out.println("Executing PurchaseAddToRequisition Method");
	}

	public void PurchaseOrderEdit(HashMap<String, String> temp){
		System.out.println("Executing PurchaseOrderEdit Method");
	}

	public void PurchaseOrderEditSubmit(HashMap<String, String> temp){
		System.out.println("Executing PurchaseOrderEditSubmit Method");
	}

	public void PurchaseOrderEditScreenValidate(HashMap<String, String> temp){
		System.out.println("Executing PurchaseOrderEditScreenValidate Method");
	}

	public void PurchaseOrderEditModifyQuantity(HashMap<String, String> temp){
		System.out.println("Executing PurchaseOrderEditModifyQuantity Method");
	}

	public void ManageRequisitionsSearch(HashMap<String, String> temp){
		System.out.println("Executing ManageRequisitionsSearch Method");
	}

	public void ManageRequisition(HashMap<String, String> temp){
		System.out.println("Executing ManageRequisition Method");
	}

	public void ManageRequisitionApprove(HashMap<String, String> temp){
		System.out.println("Executing ManageRequisitionApprove Method");
	}

	public void ManageRequisitionsStatusCheck(HashMap<String, String> temp){
		System.out.println("Executing ManageRequisitionsStatusCheck Method");
	}

	public void PurchaseOrderNonCatalogRequest(HashMap<String, String> temp){
		System.out.println("Executing PurchaseOrderNonCatalogRequest Method");
	}
	
}