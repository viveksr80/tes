package com.excelreadwrite;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.propertyreader.PropertyFileReader;

public class ExcelReadWrite {
	Row rows;
	int counter = 1;
	public static Xls_Reader excel = null;
	static PropertyFileReader propertyFileReader = new PropertyFileReader();

	public List readExcel(String filename, String sheetname) throws IOException {
		List sheetData = new ArrayList();

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);

			HSSFWorkbook workbook = new HSSFWorkbook(fis);

			HSSFSheet sheet = workbook.getSheet(sheetname);

			Iterator rows = sheet.rowIterator();
			while (rows.hasNext()) {
				HSSFRow row = (HSSFRow) rows.next();
				Iterator cells = row.cellIterator();

				List data = new ArrayList();

				int LastColNum = row.getLastCellNum();
				HSSFCell cell = null;

				System.out.println(row.getLastCellNum());

				for (int colnum = 0; colnum < LastColNum; colnum++) {

					cell = row.getCell(colnum);
					data.add(cell);
				}
				/*
				 * while (cells.hasNext()) { cell = (HSSFCell) cells.next();
				 * data.add(cell); }
				 */

				sheetData.add(data);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				fis.close();
			}
		}

		System.out.println("Sheet Name :" + sheetname);
		showsheetdata(sheetData);
		return sheetData;
	}

	public void copyTemplate(String source1, String dest1) throws Exception {
		// To copy test script template
		File source, dest;
		source = FileUtils.getFile(source1);
		dest = FileUtils.getFile(dest1);
		FileUtils.copyFile(source, dest);
	}

	private void showsheetdata(List sheetData) {
		// TODO Auto-generated method stub
		for (int i = 0; i < sheetData.size(); i++) {
			System.out.println();
			List list = (List) sheetData.get(i);
			for (int j = 0; j < list.size(); j++) {
				// covert list obj to cell and cell to string
				HSSFCell cell = (HSSFCell) list.get(j);
				String xaction = getCellValueAsString(cell);
				System.out.print("\t" + xaction);
			}
		}
	}

	public static String getCellValueAsString(Cell cell) {
		String strCellValue = null;
		if (cell != null) {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
				strCellValue = cell.toString();
				break;
			case Cell.CELL_TYPE_NUMERIC:
				if (DateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
					strCellValue = dateFormat.format(cell.getDateCellValue());
				} else {
					Double value = cell.getNumericCellValue();
					Long longValue = value.longValue();
					strCellValue = new String(longValue.toString());
				}
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				strCellValue = new String(new Boolean(cell.getBooleanCellValue()).toString());
				break;
			case Cell.CELL_TYPE_BLANK:
				strCellValue = "      ";
				break;
			}
		}
		return strCellValue;
	}

	public void writetarget(String filename, List sheetData) throws InvalidFormatException, IOException {
		// TODO Auto-generated method stub
		int col;
		// reading data from file till last row

		FileInputStream ip = new FileInputStream(filename);
		Workbook wb3 = WorkbookFactory.create(ip);
		Sheet sheet = wb3.getSheetAt(0);
		int rowsint = sheet.getLastRowNum() + 1;

		// getting last row count
		// int rowsint = 0;

		// getting row no user or last row
		/*
		 * if (rowno == 0) { try { rowsint = sheet.getLastRowNum(); } catch
		 * (Exception e) { System.out.println(e.getMessage()); }
		 * 
		 * } else { //rowsint = rowno; }
		 */
		System.out.println(" last row" + rowsint);

		// appending the data
		for (int i = 0; i < sheetData.size(); i++) {

			System.out.println();
			List list = (List) sheetData.get(i);
			// rowsint=rowsint+1;
			if (i == 0) {
				rows = sheet.createRow(rowsint);
			} else if (i > 0) {
				rows = sheet.createRow(++rowsint);
			}
			col = 0;

			for (int j = 0; j < list.size(); j++) {
				// covert list obj to cell and cell to string
				HSSFCell cellt = (HSSFCell) list.get(j);
				String xaction = getCellValueAsString(cellt);
				// System.out.print("\t"+xaction);

				// adding the string obj to cell
				if (col == 0) {
					xaction = Integer.toString(counter);
					Cell cell = rows.createCell(col++);
					cell.setCellValue(xaction);
					counter++;
				} else {

					Cell cell = rows.createCell(col++);
					cell.setCellValue((String) xaction);
				}
			}
		}
		ip.close();

		// ***************************writing in file******
		FileOutputStream out = new FileOutputStream(new File(filename));
		wb3.write(out);
		out.close();

		System.out.println(filename + " written successfully");

	}

	public static void updateRO(String[] RnClsName) {

		String runnerRepoPath = propertyFileReader.getValue("RunnerRepo");
		excel = new Xls_Reader(runnerRepoPath);

		int rowcount = excel.getRowCount("Sheet1");

		for (int j = 6; j <= rowcount; j++) {

			for (String runnerClassName : RnClsName) {

				String RnClsName1 = "com.accenture.runner.selenium.ExecuteScript" + runnerClassName;
				String runnerName = excel.getCellData("Sheet1", 1, j + 1);
				String execute = excel.getCellData("Sheet1", 2, j + 1);

				if (runnerName.equalsIgnoreCase(RnClsName1) && execute.equalsIgnoreCase("yes")) {

					System.out.println("runner class present and it has set to runner mode yes");

					j++;
					continue;
				} else if (runnerName.equalsIgnoreCase(RnClsName1)
						&& (execute.equalsIgnoreCase("no") || execute.equalsIgnoreCase(""))) {
					excel.setCellData("Sheet1", "Execute?", j + 1, "Yes");

					j++;
					continue;
				} else {

					String LastSlNoVal = excel.getCellData("Sheet1", 0, excel.getRowCount("Sheet1"));
					int NextSlNo;
					int rownumber = excel.getRowCount("Sheet1");

					if (LastSlNoVal.equalsIgnoreCase("")) {
						excel.setCellData("Sheet1", "Sl No", rownumber + 1, String.valueOf("1"));
					} else if (!LastSlNoVal.equalsIgnoreCase("Sl No")) {
						Float LstSlNoVal = Float.valueOf(LastSlNoVal);
						NextSlNo = LstSlNoVal.intValue() + 1;
						excel.setCellData("Sheet1", "Sl No", rownumber + 1, String.valueOf(NextSlNo));
					} else if (LastSlNoVal.equalsIgnoreCase("Sl No")) {
						excel.setCellData("Sheet1", "Sl No", rownumber + 1, String.valueOf("1"));
					}

					excel.setCellData("Sheet1", "Runner Name", j + 1, RnClsName1);
					excel.setCellData("Sheet1", "Execute?", j + 1, "Yes");
					j++;
				}
			}
		}
	}
}
