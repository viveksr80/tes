package com.features;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.ttporacleapps.OpenNLP_Categorizer_Tool;
import com.ttporacleapps.TextFileHandler;

public class ReadFeatureFile extends OpenNLP_Categorizer_Tool {

	static C1S2RWordParser parser = null;
	static PrintStream printStream = null;
	static String generationType;
	int lineCount = 0;
	String currentLine = "";
	static int stepCount = 1;
	FileOutputStream fileOutputStream = null;
	Map<Integer, String> featureMap;
	Map<Integer, String> keywordMap;
	OpenNLP_Categorizer_Tool oct = new OpenNLP_Categorizer_Tool();

	public ReadFeatureFile() {
		featureMap = new HashMap<>();
		keywordMap = new HashMap<>();
	}

	public static void main(String[] args) throws IOException {

		ReadFeatureFile readfeaturefile = new ReadFeatureFile();
		parser = new C1S2RWordParser();

		
		readfeaturefile.createReusableMethodClass(new File("C:\\Users\\akash.a.murumkar\\Desktop\\Telus_Feature files\\ReusableMethods.java"),"ReusableMethods");
		
		TextFileHandler.CreateTextFile("C:\\Users\\akash.a.murumkar\\Desktop\\Telus_Feature files", "CaseReviewLoanstatus");

		readfeaturefile.readFeatureFile("C:\\Users\\akash.a.murumkar\\Desktop\\Telus_Feature files\\CaseReviewLoanstatus.feature");
		
		readfeaturefile.getNonActionsList("CaseReviewLoanstatus");

		// List<String> collectNonActions =
		// ReadFeatureFile.getNonActionsList("EditProfile");

		// System.out.println(collectNonActions.size());

		// TextFileHandler.DeleteTextFile("C:\\Users\\vivek.sr\\Desktop\\Telus_Feature
		// files", "EditProfile");

		// List<String> nonActionsList =
		// ReadFeatureFile.getNonActionsList("TestCase");
		// ReadFeatureFile f = new ReadFeatureFile();
		// f.processLogic(collectNonActions);

	}

	@SuppressWarnings("resource")

	public List<String> readFeatureFile(String featureFilePath) throws IOException {

		File file = new File(featureFilePath);

		Scanner scanner;
		scanner = new Scanner(file);
		String currentLine = "";
		String str = "";
		List<String> list = new ArrayList<String>();

		while (scanner.hasNextLine()) {

			currentLine = scanner.nextLine();
			currentLine = currentLine.trim();
			if (currentLine.length() > 0) {

				if (currentLine.trim().startsWith("Given ") || currentLine.trim().startsWith("When ")
						|| currentLine.trim().startsWith("Then ") || currentLine.trim().startsWith("And ")
						|| currentLine.trim().startsWith("But "))
					try {
						lineCount++;
						String keyword = currentLine.substring(0, currentLine.indexOf(" "));
						currentLine = currentLine.trim().substring(keyword.length() + 1);
						str = str.trim() + "\n" + "\n" + currentLine.trim() + "\n";
						featureMap.put(lineCount, currentLine);
						keywordMap.put(lineCount, keyword);
						TextFileHandler.WriteToFile(
								"C:\\Users\\vivek.sr\\Desktop\\Telus_Feature files\\CaseReviewLoanstatus.txt",
								currentLine.trim());

						list.add(str);

					} catch (IndexOutOfBoundsException exp) {
						System.out.println(exp.getStackTrace());
					}
			}
		}
		// System.out.println(str);
		return list;
	}

	public Map<Integer, String> getNonActionsList(String TestCase) throws IOException {
		createScriptFile(new File("C:\\Users\\vivek.sr\\Desktop\\Telus_Feature files\\CaseReviewLoanstatus.java"),
				TestCase);
		ArrayList<String> actionsList = oct.getActionsList(TestCase);

		//System.out.println(actionsList.get(0));

		Map<Integer, String> noActionFoundList = new HashMap<Integer, String>();
		Map<Integer, String> ActionFoundList = new HashMap<Integer, String>();

		int size = actionsList.size();

		for (int i = 0; i < size; i++) {

			String string = actionsList.get(i).trim();

			String currentline = featureMap.get(i + 1);
			String currentKeyword = keywordMap.get(i + 1);
			//System.out.println(currentKeyword);
			String[] split = string.split("\\|");

			String featureline = currentline.replaceAll("\\s+", "_");
			// String featureline =
			// currentline.split("\\s+")[1].replaceAll("\\s+", "_");

			if (string.contains("No_Action_Found")) {
				// System.out.println(keyword);
				// createMethod(currentline.split("\\s+")[0], currentline,
				// featureline);
				createMethod(currentKeyword, currentline, featureline);
				noActionFoundList.put(i + 1, split[1]);

				System.out.println(split[1]);

			} else {
				// System.out.println(keyword);
				// createMethod1(currentline.split("\\s+")[0], currentline,
				// featureline);
				ActionFoundList.put(i+1, split[1]);
				System.out.println(split[1]);
				System.out.println(split[0]);
				String methodName = split[0];
				createMethod1(currentKeyword, currentline, featureline, methodName );
			}
		}
		return noActionFoundList;
	}

	/*
	 * public void processLogic(Map<Integer, String> nonActionsListList) throws
	 * IOException { int size = nonActionsListList.size(); Iterator<Integer> it
	 * = nonActionsListList.keySet().iterator();
	 * 
	 * createScriptFile(new
	 * File("C:\\Users\\vivek.sr\\Desktop\\Telus_Feature files\\EditProfile.java"
	 * ), "EditProfile");
	 * 
	 * for (;it.hasNext();) { int key = it.next(); String currentline =
	 * featureMap.get(key); String featureline =
	 * currentline.split("\\s+")[1].replaceAll("\\s+", "_");
	 * createMethod(currentline.split("\\s+")[0], currentline, featureline);
	 * 
	 * // ReadFeatureFile.createMethod(nonActionsListList.get(i));
	 * parser.doProcess("click on the button", 1, null);
	 * System.out.println(parser.getKeywords());
	 * 
	 * } }
	 */

	private void createMethod1(String keyword, String currentLine, String featureLine, String methodName) {

		printStream.println("\t/**");
		printStream.println("\t * Step definition for " + currentLine);
		printStream.println("\t *");
		printStream.println("\t * @param keyword  the keyword to display. ");
		printStream.println("\t * @param currentLine  description of step definition. ");
		printStream.println("\t * @param featureLine  the step definition to be invoked. ");
		printStream.println("\t */");

		featureLine = processCurrentLine(printStream, keyword, currentLine, featureLine);

		printStream.println("");
		printStream.println("\t\t//Entered " + currentLine);
		printStream.println("\t\textentTest.log(LogStatus.PASS, \"Entered " + featureLine.toLowerCase() + "\");");
		// printStream.println("\t\tCTLogger.writeToLog(\"" +
		// featureLine.toLowerCase() + "\");");
		printStream.println("");
		printStream.println("\t\t//Automation Code");
		printStream.println("\t\treusablemethod." + methodName.trim()+"();" );
		//printStream.println("\tSelectFromList selectFromList = new SelectFromList();");
		//addLogics1(currentLine, printStream, featureLine, null);

		printStream.println("");
		printStream.println("\t\textentTest.log(LogStatus.INFO, \"Coming out of " + featureLine.toLowerCase() + "\");");
		// printStream.println("\t\t//throw new PendingException();");
		printStream.println("\t} ");
		printStream.println("");
	}

	private void createMethod(String keyword, String currentLine, String featureLine) {

		printStream.println("\t/**");
		printStream.println("\t * Step definition for " + currentLine);
		printStream.println("\t *");
		printStream.println("\t * @param keyword  the keyword to display. ");
		printStream.println("\t * @param currentLine  description of step definition. ");
		printStream.println("\t * @param featureLine  the step definition to be invoked. ");
		printStream.println("\t */");

		featureLine = processCurrentLine(printStream, keyword, currentLine, featureLine);

		printStream.println("");
		printStream.println("\t\t//Entered " + currentLine);
		printStream.println("\t\textentTest.log(LogStatus.PASS, \"Entered " + featureLine.toLowerCase() + "\");");
		// printStream.println("\t\tCTLogger.writeToLog(\"" +
		// featureLine.toLowerCase() + "\");");
		printStream.println("");
		printStream.println("\t\t//Automation Code");

		addLogics(currentLine, printStream, featureLine, null);

		printStream.println("");
		printStream.println("\t\textentTest.log(LogStatus.INFO, \"Coming out of " + featureLine.toLowerCase() + "\");");
		// printStream.println("\t\t//throw new PendingException();");
		printStream.println("\t} ");
		printStream.println("");
	}

	private String processCurrentLine(PrintStream printStream, String keyword, String currentLine, String featureLine) {
		String replaceString = "\\\"([^\\\"]*)\\\"";

		if (featureLine.indexOf("$") > -1) {
			featureLine = featureLine.replaceAll("\\$", "");
		}

		if (currentLine.indexOf("\"") > -1) {

			char[] line = currentLine.toCharArray();
			StringBuilder builder = new StringBuilder();
			StringBuilder builder1 = new StringBuilder();
			StringBuilder builder2 = new StringBuilder();
			boolean insideQuotes = false;
			boolean replaced = false;
			int q_counter = 0;

			for (int i = 0; i < line.length; i++) {
				if (line[i] == '"') {
					insideQuotes = !insideQuotes;
					replaced = false;
					continue;
				} else {
					if (!insideQuotes) {
						builder.append(line[i]);
						builder2.append(line[i]);
					} else {
						if (!replaced) {
							q_counter++;
							builder.append(replaceString);
							replaced = true;
						}
					}
				}
			}

			for (int j = 0; j < q_counter; j++) {
				if (j > 0) {
					builder1.append(", ");
				}
				builder1.append("String args").append((j + 1));
			}

			featureLine = builder2.toString();
			featureLine = featureLine.replaceAll(" ", "_");

			printStream.println("\t@" + keyword + "(\"^" + builder.toString() + "$\")");
			printStream.println(
					"\t public void " + featureLine.toLowerCase() + "(" + builder1.toString() + ") throws Throwable {");

		} else {
			printStream.println("\t@" + keyword + "(\"^" + currentLine + "$\")");

			printStream.println("\t public void " + featureLine.toLowerCase() + "() throws Throwable {");

		}

		return featureLine;

	}

	private void addLogics(String line, PrintStream printStream, String featureLine, String generationType) {

		Iterator<String> it = null;
		if (generationType != null && "manual".equals(generationType)) {
			/*
			 * parserManual.doProcess(featureLine); it =
			 * parserManual.getKeywords().keySet().iterator();
			 */
			parser.doProcess(line, lineCount, generationType);
			it = parser.getKeywords().keySet().iterator();
		} else {
			parser.doProcess(line, lineCount, generationType);
			it = parser.getKeywords().keySet().iterator();
		}

		for (; it.hasNext();) {
			String key = it.next();
			String keyword = null;
			String data = null;
			String locator = null;
			if (key != null && key.indexOf("-") > -1) {
				keyword = key.substring(key.indexOf("-") + 1);
				if (generationType != null && "manual".equals(generationType)) {
					/*
					 * LineVO lineVo = parserManual.getLineVO(key); data =
					 * lineVo.getData(); locator = lineVo.getLocator();
					 */
					data = parser.getData(key);
					locator = parser.getLocator(key);
				} else {
					data = parser.getData(key);
					locator = parser.getLocator(key);
				}

				locator = (locator == null) ? ""
						: (locator.endsWith("_") ? locator.substring(0, locator.length() - 1) : locator);

				// locator = locatorLogic.renderLocator(locator, keyword);

				if (data == null) {
					data = "dataMap.get(\"" + locator + "\")";
				} else {
					if (data.indexOf("@data@") > -1) {
						data = data.replaceAll("@data@", "args");
					}
				}

				switch (keyword) {

				case "LAUNCH":
					printStream.println("\t\tlaunch.launchUrl(driver, " + data + ", extentTest);");
					break;

				case "INPUT":
					printStream.println("\t\tobjectMapVO = objectMap.get(\"" + locator + "\");");
					printStream.println(
							"\t\tinput.enterText(driver, objectMapVO.getObjectPath(), objectMapVO.getSelector(), "
									+ data + ", extentTest, objectMapVO.getControlName());");
					break;

				case "CLICK":
					printStream.println("\t\tobjectMapVO = objectMap.get(\"" + locator + "\");");
					printStream.println(
							"\t\tclick.click(driver, objectMapVO.getObjectPath(), objectMapVO.getSelector(), extentTest, objectMapVO.getControlName());");
					break;

				case "WAIT":
					printStream.println("\t\twaitTime.waitTime(" + data + ", extentTest, \"wait\");");
					break;

				case "MOUSEOVER":
					printStream.println("\t\tobjectMapVO = objectMap.get(\"" + locator + "\");");
					printStream.println(
							"\t\tmouseOverAndClick.mouseOverAndSelect(driver, objectMapVO.getObjectPath(), objectMapVO.getSelector(), \"\", extentTest, objectMapVO.getControlName());");
					break;

				case "MOUSEOUT":
					printStream.println("\t\tobjectMapVO = objectMap.get(\"" + locator + "\");");
					printStream
							.println("\t\tclick.click(driver, objectMapVO.getObjectPath(), objectMapVO.getSelector(), "
									+ data + ", objectMapVO.getControlName());");
					break;

				case "SELECT":
					printStream.println("\t\tobjectMapVO = objectMap.get(\"" + locator + "\");");
					printStream.println(
							"\t\tselectFromList.selectFromList(driver, objectMapVO.getObjectPath(), objectMapVO.getSelector(), "
									+ data + ", objectMap.get(\"" + locator
									+ "-type\"), extentTest, objectMapVO.getControlName());");
					break;
				}

			}
		}

	}

	public void createScriptFile(File scriptFile, String CaseReviewLoanstatus) throws IOException {
		try {
			scriptFile.createNewFile();
			fileOutputStream = new FileOutputStream(scriptFile);
			printStream = new PrintStream(fileOutputStream);

			printStream.println("package cucumber.stepdefs;\n");

			printStream.println("import java.util.Map;");
			printStream.println("import java.util.Set;");
			printStream.println("import java.util.HashMap;");
			printStream.println("import java.util.Iterator;");
			printStream.println("import java.util.LinkedHashMap;");
			printStream.println("import java.util.List;\n");

			printStream.println("import org.openqa.selenium.WebDriver;\n");

			printStream.println("import cucumber.api.PendingException;");
			printStream.println("import cucumber.api.java.en.*;");
			printStream.println("import cucumber.api.junit.Cucumber;");
			printStream.println("import org.junit.runner.RunWith;");
			printStream.println("import org.openqa.selenium.WebDriver;\n");

			printStream.println("import com.relevantcodes.extentreports.ExtentTest;");
			printStream.println("import com.relevantcodes.extentreports.LogStatus;\n");
			printStream.println("import com.accenture.aaft.excel.utility.ExcelTestDataReader;");
			printStream.println("import com.accenture.aaft.excel.utility.ObjectMapReader;");
			// printStream.println("import
			// com.accenture.aaft.logger.CTLogger;");
			printStream.println("import com.accenture.aaft.report.ExtentTestManager;");
			printStream.println("import com.accenture.aaft.selenium.driver.SeleniumDriver;");
			printStream.println("import com.accenture.aaft.selenium.library.*;");
			printStream.println("import com.accenture.aaft.vo.ExcelTestDataVO;\n");
			printStream.println("import com.accenture.aaft.vo.ObjectMapVO;\n");

			printStream.println("");

			printStream.println("/**");

			printStream.println(" * Step Definitions for running tests using Cucumber");

			printStream.println(" * ");
			// printStream.println(" * @author " + user);
			printStream.println(" */\n");

			printStream.println("@RunWith(Cucumber.class)");
			printStream.println("public class " + CaseReviewLoanstatus + " {\n");
			printStream.println("\tstatic ExtentTest extentTest;\n");
			printStream.println("\tprivate WebDriver driver;\n");
			
			printStream.println("\tString objectMapFile = \"\";\n");
			

			printStream.println("\t//Smarttesting Journey Library objects");
			printStream.println("\tReusableMethods reusablemethod = new ReusableMethods();");
			printStream.println("\tLaunchUrl launch = new LaunchUrl();");
			printStream.println("\tClick click = new Click();");
			printStream.println("\tWaitTime waitTime = new WaitTime();");
			printStream.println("\tInput input = new Input();");
			printStream.println("\tSelectFromList selectFromList = new SelectFromList();");
			printStream.println("\tMouseOverAndClick mouseOverAndClick = new MouseOverAndClick();\n");

			printStream.println("\t//Web Object related");
			printStream.println("\tObjectMapVO objectMapVO = null;");
			printStream.println("\tLinkedHashMap<String, ObjectMapVO> objectMap; \n");

			printStream.println("\t//Data related objects");
			printStream.println("\tLinkedHashMap<String, List<ExcelTestDataVO>> testDataMap = null;");
			printStream.println("\tMap<String, String> dataMap = new HashMap<>();");
			printStream.println("\tList<ExcelTestDataVO> voList;");

			printStream.println("\tpublic " + CaseReviewLoanstatus + "() {");

			printStream.println("\t\ttry{");

			printStream.println("\t\t\tdriver = SeleniumDriver.getWebDriver(\"chrome\");   //Webdriver object");
			printStream.println("\t\t\textentTest = ExtentTestManager.getTest();   //Extent logger Object");
			printStream.println("\t\t\textentTest.log(LogStatus.INFO, \"Starting test " + CaseReviewLoanstatus + "\");");
			// printStream.println("\t\t\tCTLogger.writeToLog(\"" + fileName + "
			// extentTest - \"+extentTest); \n");

			printStream.println("\t\t\t//read the Object repository");
			printStream.println("\t\t\tObjectMapReader objectMapReader = new ObjectMapReader();");

			printStream.println("\t\t\tobjectMap = objectMapReader.readObjectMap(objectMapFile);\n");

			printStream.println("\t\t\t//read the data repository");
			printStream.println("\t\t\tExcelTestDataReader excelTestDataReader = new ExcelTestDataReader();");

			printStream.println("\t\t\ttestDataMap = excelTestDataReader.readTestData(\"" + CaseReviewLoanstatus + "\");");

			printStream.println("\t\t\tSet<String> set = testDataMap.keySet();");
			printStream.println("\t\t\tIterator<String> it = set.iterator();");
			printStream.println("\t\t\tString key = it.next();");
			printStream.println("\t\t\tvoList = (List<ExcelTestDataVO>) testDataMap.get(key);\n");
			printStream.println("\t\t\t//adding all the data key and value pair to the data map;");
			printStream.println("\t\t\tfor (ExcelTestDataVO vo : voList) {");
			printStream.println("\t\t\t\tdataMap.put(vo.getName(), vo.getValue());");
			printStream.println("\t\t\t}");

			printStream.println("\t\t} catch(Exception ex) {");
			printStream.println("\t\t\ttry {	");
			printStream.println("\t\t\t\tex.printStackTrace();");
			// printStream.println(
			// "\t\t\t\tCTLogger.writeToLog(\"" + fileName + "\",\"constructor
			// called\",\" exception occured\");");
			printStream.println("\t\t\t} finally {");
			printStream.println("\t\t\t\tString[] err = ex.getMessage().split(\"\\n\");");
			printStream
					.println("\t\t\t\tString status = \"Exception \" +err[0].replaceAll(\"'\", \"\") + \" Occurred\";");
			printStream
					.println("\t\t\t\textentTest.log(LogStatus.FAIL, \"failed to load dependency classes \"+status);");
			printStream.println("\t\t\t}");
			printStream.println("\t\t}");
			printStream.println("\t} \n\n");

		} catch (FileNotFoundException e) {
			printStream.println("e.printStackTrace();");
			printStream.println("} catch (IOException e) {");
			printStream.println("	e.printStackTrace();");
		}
	}
	
	public void createReusableMethodClass(File scriptFile, String className) throws IOException {
		try {
			scriptFile.createNewFile();
			fileOutputStream = new FileOutputStream(scriptFile);
			printStream = new PrintStream(fileOutputStream);
			printStream.println("import java.util.Map;");
			printStream.println("import java.util.Set;");
			printStream.println("import java.util.HashMap;");
			printStream.println("import java.util.Iterator;");
			printStream.println("import java.util.LinkedHashMap;");
			printStream.println("import java.util.List;\n");
			printStream.println("import org.openqa.selenium.WebDriver;\n");
			printStream.println("import com.relevantcodes.extentreports.ExtentTest;");
			printStream.println("import com.relevantcodes.extentreports.LogStatus;\n");
			printStream.println("import com.accenture.aaft.excel.utility.ExcelTestDataReader;");
			printStream.println("import com.accenture.aaft.excel.utility.ObjectMapReader;");
			printStream.println("import com.accenture.aaft.report.ExtentTestManager;");
			printStream.println("import com.accenture.aaft.selenium.driver.SeleniumDriver;");
			printStream.println("import com.accenture.aaft.selenium.library.*;");
			printStream.println("import com.accenture.aaft.vo.ExcelTestDataVO;\n");
			printStream.println("import com.accenture.aaft.vo.ObjectMapVO;\n");

			printStream.println("");

			printStream.println("/**");
			printStream.println(" * ");

			printStream.println(" */\n");

			printStream.println("public class " + className + " {\n");
			printStream.println("\tstatic ExtentTest extentTest;\n");
			printStream.println("\tprivate WebDriver driver;\n");
			
			printStream.println("\tString objectMapFile = \"\";\n");
		
			printStream.println("\t//Web Object related");
			printStream.println("\tObjectMapVO objectMapVO = null;");
			printStream.println("\tLinkedHashMap<String, ObjectMapVO> objectMap; \n");

			printStream.println("\t//Data related objects");
			printStream.println("\tLinkedHashMap<String, List<ExcelTestDataVO>> testDataMap = null;");
			printStream.println("\tMap<String, String> dataMap = new HashMap<>();");
			printStream.println("\tList<ExcelTestDataVO> voList;");

			printStream.println("\t} \n\n");

		} catch (FileNotFoundException e) {
			printStream.println("e.printStackTrace();");
			printStream.println("} catch (IOException e) {");
			printStream.println("	e.printStackTrace();");
		}
	}
}
