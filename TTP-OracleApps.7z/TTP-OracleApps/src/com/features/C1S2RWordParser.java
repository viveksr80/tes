package com.features;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;




/**
 * C1S2R Parser Used to infer the keywords to be used in the 
 * 		1. Cucumber Step definition
 * 		2. Manual test steps
 * 
 * @author s.c.ramalingam
 *
 */
public class C1S2RWordParser {
	
	public static String INSIGNIFICANT_WORDS = "~a~in~of~the~it~for~as~to~on~i~by~be~was~were~is~";
	private static String ALL_KEYWORDS = null;
	
	private String dataSeparator = ":";
	private boolean isZ0Required = true;
	private String previousKeyowrd = null;
	private String lastKeyword = null;
	
	int count = 0;
	int lineCount = 0;
	String currentLine = null;
	
	private Map<String, String> dataMap;
	private Map<String, String[]> dataAttributeMap;
	private Map<String, String> keywordsMap;
	private Map<String, String> tempKeywordsMap;
	private Map<String, String> locatorMap;
	private Map<String, String> dataToStepMap;
	private Map<String, Boolean> isReverseMap;
	private String considerKeyword = "";
	private String notConsiderKeyword = "";
	
	protected static Map<String, String> keywordsMatchingMap;
	protected static Map<String, String> wordMatchingMap;
	protected static Map<String, String> considerationMap;
	
	PropertyReader pr = null;
	
	
	public C1S2RWordParser() throws IOException {
		dataMap = new HashMap<>();
		locatorMap = new HashMap<>();
		dataToStepMap = new HashMap<>();
		dataAttributeMap = new HashMap<>();
		keywordsMap = new LinkedHashMap<>();
		tempKeywordsMap = new LinkedHashMap<>();
		isReverseMap = new HashMap<>();
		
		keywordsMatchingMap = new HashMap<>();
		wordMatchingMap = new HashMap<>();
		considerationMap = new HashMap<>();
		
		init();
	}


	public void doProcess(String line, int lineNumber, String manual) {
		lineCount = lineNumber;
		tempKeywordsMap.clear();
		currentLine = line;
		
		boolean isManualProcessed = false;
		if (manual != null) {
			isManualProcessed = c0Process(line);
		}
		
		if (!isManualProcessed) {
			String processedline = z0Process(line);
			//System.out.println(processedline);
			processedline = z1Process(processedline);
			if (processedline.indexOf(",") > -1) {
				processedline = processedline.replaceAll(",", " and ");
			}
			//System.out.println(processedline);
			s0Process(processedline);
			s1Process(processedline);
		}

	}
	
	public Map<String, String> getKeywords() {
		return tempKeywordsMap;
	}
	
	public String getLocator(String key) {
		return locatorMap.get(key);
	}
	
	public String getData(String key) {
		return dataToStepMap.get(key);
	}
	
	public String getActualData(String key) {
		return dataMap.get(key);
	}
	
	private void init() throws IOException {
		pr = PropertyReader.getInstance();
		if (keywordsMatchingMap.isEmpty() && wordMatchingMap.isEmpty()) {
			StringBuilder all_keywords = new StringBuilder();
			Iterator<Object> it = pr.keyMatchMapWP.keySet().iterator();
			for (;it.hasNext();) {
				String key = (String) it.next();
				all_keywords.append(key);
				keywordsMatchingMap.put(key, pr.keyMatchMapWP.getProperty(key));
			}
			it = pr.wordMatchMapWP.keySet().iterator();
			for (;it.hasNext();) {
				String key = (String) it.next();
				all_keywords.append(key);
				wordMatchingMap.put(key, pr.wordMatchMapWP.getProperty(key));
			}
			it = pr.s1Map.keySet().iterator();
			for (;it.hasNext();) {
				String key = (String) it.next();
				all_keywords.append(key);
				considerationMap.put(key, pr.s1Map.getProperty(key));
			}
			
			
			ALL_KEYWORDS = all_keywords.toString().replaceAll("~~", "~");
		}
	}
	
	/**
	 * C0 process
	 * separate the data from the requirement for Manual Test cases
	 * 
	 */
	private boolean c0Process(String inputLine) {
		boolean processed = false;
		if (inputLine != null && inputLine.contains(":") && inputLine.contains("\n")) {
			z0Process(inputLine);
			z1Process(inputLine);
			StringBuilder builder = new StringBuilder();
			String[] lines = inputLine.split("\\n");
			for (int i=0 ;i<lines.length; i++) {
				if (lines[i] != null && lines[i].trim().isEmpty()) {
					continue;
				}
				if (i > 0) {
					builder.append("\n");
				}
				if (i == 0) {
					s0Process(lines[i]);
					s1Process(lines[i]);
				} else {
					if (lines[i].indexOf(":") > -1) {
						String locatorValue[] = lines[i].split(":");
						String locator = locatorValue[0].trim();
						String value = null;
						if (locatorValue.length > 1 && locatorValue[1] != null)
							value = locatorValue[1].trim();
						else 
							value = "Please enter the value";
						tempKeywordsMap.put(++count + "-" + lastKeyword, value);
						dataToStepMap.put(count + "-" + lastKeyword, value);
						locatorMap.put(count + "-" + lastKeyword, locator);
					} else {
						s0Process(lines[i]);
						s1Process(lines[i]);
					}
				}
			}
			processed = true;
		}	
		return processed;
	}
	
	/**
	 * Z0 process
	 * Separate the data from the requirement for Feature lines
	 * 
	 * @param inputLine
	 * @return
	 * 		Processed line, that does not contain the data
	 */
	private String z0Process(String inputLine) {
		String temp;
		StringBuilder builder = null;
		if (inputLine != null && inputLine.indexOf("\"") > -1) {
			int i = 0;
			int strIndex = 0;
			int index = inputLine.indexOf("\"");
			builder = new StringBuilder();
			while (index > -1 || strIndex < inputLine.length()) {
				try {
					temp = inputLine.substring(strIndex, index);
					builder.append(temp);
					strIndex = inputLine.indexOf("\"", index + 1) + 1;
					if (index > -1) {
						builder.append("@data@" + (i+1));
						dataMap.put("@data@" + (i+1), inputLine.substring(index + 1, strIndex - 1));
						dataAttributeMap.put("@data@" + (i+1), temp.trim().split("\\s+"));
						i++;
					}				
					index = inputLine.indexOf("\"", strIndex);
				} catch (IndexOutOfBoundsException ie) {
					builder.append(inputLine.substring(strIndex));
					break;
				}				
			}
		}
		return (builder != null  && builder.length() > 0) ? builder.toString() : inputLine;
	}
	
	/**
	 * Z1 process 
	 * This process is to combine the two words to form a single word
	 * 
	 * @param inputLine
	 * @return
	 * 		Processed line, that contains the combined words (if any)
	 */
	private String z1Process(String inputLine) {
		
		//replace all comma to and
		inputLine = inputLine.replaceAll(",", " and ");	
		
		StringBuilder processedLine = null;
		if (inputLine != null) {
			String[] array = inputLine.split("\\s+");
			String all_words = pr.z1Map.getProperty("ALL_WORDS");
			processedLine = new StringBuilder();
			for (int a = 0; a < array.length; a++) {
				if (all_words != null && array[a] != null) {
					if (all_words.indexOf("~" + array[a] + "~") > -1) {
						String supportingWords = pr.z1Map.getProperty(array[a]);
						if (supportingWords != null && supportingWords.indexOf("~" + array[a + 1] + "~") > -1) {
							processedLine.append(array[a]).append(array[a + 1]).append(" ");
							a++;
						}
					} else {
						processedLine.append(array[a]).append(" ");
					}
				}
			}
		}		
		return (processedLine.length() > 0) ? processedLine.toString().trim() : inputLine;
	}
	
	/**
	 * S0 Process
	 * This process is used to find the Keywords associated with it
	 * 
	 * @param inputLine
	 */
	private void s0Process(String inputLine) {
		if (inputLine != null) {
			match(inputLine.split("\\s+"));			
		}
	}
	
	/**
	 * S1 Process
	 * This process is used to associate data to the Keywords
	 * 
	 * @param inputLine
	 */
	private void s1Process(String inputLine) {
		if (inputLine != null) {
			Iterator<String> it = tempKeywordsMap.keySet().iterator();
			while (it.hasNext()) {
				String keyword = it.next();
				String inputLinePart = tempKeywordsMap.get(keyword);
				if (inputLine.contains(inputLinePart.trim())) {
					String inputLineTemp = inputLine;
					boolean isReverse = false;
					if (isReverseMap.get(keyword) != null) {
						isReverse = isReverseMap.get(keyword);
						inputLineTemp = inputLinePart;
					} else {
						if (inputLine.trim().length() == inputLinePart.trim().length()) {
							isReverse = true;
						} else {
							inputLineTemp = inputLine.substring(inputLine.indexOf(inputLinePart) + inputLinePart.length());
						}
					}
					
					String[] wordsArray = inputLineTemp.split("\\s+");
					// used to get the data associated with each line
					getData(wordsArray, keyword, isReverse);
					// used to get the locators associated with each line
					getLocators(wordsArray, keyword, isReverse);
					
					//if locator is null or empty, reiterate to get the actual
					if (!isReverse) {
						String locator = locatorMap.get(keyword);
						if (locator == null || locator.trim().isEmpty()) {
							getLocatorReiterate(keyword, inputLinePart);						
						}
					}					
				}
			}	
			
			keywordsMap.putAll(tempKeywordsMap);
		}
	}
	
	private void match(String[] array) {
		String lastValue = null;
		lastKeyword = null;
		boolean isKeywordMatched = false;
		StringBuilder lineBuilder = new StringBuilder();
		int j = 0;
		for (int i = 0; i < array.length; i++) {
			isKeywordMatched = false;	
			String word = array[i];
			//word = stemerObj.stem(word);
			//System.out.println("Base word: " + array[i]);
			//System.out.println("Stem word: " + word);
			if (array[i] != null && !array[i].trim().isEmpty()) {
				if (array[i].trim().equalsIgnoreCase("and")) {
					j++;
					lineBuilder.append(array[i]).append(" ");
					if (j > 1) {
						isReverseMap.put(count + "-" + lastKeyword, true);
						tempKeywordsMap.put(count + "-" + lastKeyword, lineBuilder.toString());
						previousKeyowrd = lastKeyword;
						j = 0;
						count++;
					}
					continue;
				}				
				lineBuilder.append(array[i]).append(" ");
				Iterator<String> it = keywordsMatchingMap.keySet().iterator();
				while (it.hasNext()) {
					String key = it.next();
					boolean add = false;
					if (key.startsWith("-")) {
						if (key.indexOf("-" + array[i].toLowerCase() + "-") > -1) {
							if (key.length() > key.lastIndexOf("-")+1) {
								String otherWords = key.substring(key.lastIndexOf("-") + 1);
								String[] otherWordsArray = otherWords.split("~");
								StringBuilder tempLine = new StringBuilder();
								for (int k = i+1; k < array.length; k++) {
									if (tempLine.length() > 0) {
										tempLine.append(" ");
									}
									tempLine.append(array[k]);
								}
								int a = 0;
								while (a < otherWordsArray.length) {
									int index = tempLine.toString().toLowerCase().indexOf(otherWordsArray[a].toLowerCase());
									if (index != -1) {
										int lengthIndex = index + otherWordsArray[a].length();
										if ((index == 0 && (tempLine.toString().toLowerCase()
												.indexOf(otherWordsArray[a].toLowerCase() + " ") > -1))
												|| (lengthIndex == tempLine.toString().toLowerCase().length() && (tempLine.toString().toLowerCase()
														.indexOf(" " + otherWordsArray[a].toLowerCase()) > -1))
												|| (tempLine.toString().toLowerCase()
														.indexOf(" " + otherWordsArray[a].toLowerCase() + " ") > -1)) {											
											add = true;
											lastKeyword = keywordsMatchingMap.get(key);
											lastKeyword = (lastKeyword.indexOf("~") > -1) ? lastKeyword.split("~")[0] : lastKeyword;
											break;
										}
									}									
									a++;
								}
								if (!add) {
									add = true;
									lastKeyword = keywordsMatchingMap.get(key);
									lastKeyword = (lastKeyword.indexOf("~") > -1) ? lastKeyword.split("~")[1] : lastKeyword;
								}
							} else {
								add = true;
							}							
						}
					} else if (key.indexOf("~" + array[i].toLowerCase() + "~") > -1) {						
						lastKeyword = keywordsMatchingMap.get(key);
						add = true;
					}					
					if (add) {
						String considerType = considerationMap.get(lastKeyword);
						if (considerType != null) {
							if (lastKeyword.equals("LAUNCH") && lineCount >= 2) {
								continue;
							} else {
								/*switch (considerType) {
								case "ONLY_ONE":
									if (previousKeyowrd.equals(lastKeyword)) {
										tempKeywordsMap.get((count-1) + "-" + previousKeyowrd);
								}*/
							}
						}
						if (notConsiderKeyword.indexOf("~" + lastKeyword + "~") > -1) {
							continue;
						}
						isKeywordMatched = true;
						lastValue = lineBuilder.toString();
						tempKeywordsMap.put(count + "-" + lastKeyword, lastValue);
						previousKeyowrd = lastKeyword;
						j = (j > 0) ? j-1 : j;
						count++;
						if (lastKeyword.equals("LAUNCH"))
							notConsiderKeyword += "~LAUNCH~";
								
					} else {
						if (j > 1) {
							tempKeywordsMap.put(count + "-" + lastKeyword, lineBuilder.toString());
							previousKeyowrd = lastKeyword;
							j = 0;
							count++;
						}
					}
				}				
				
				if (!isKeywordMatched) {
					it = wordMatchingMap.keySet().iterator();
					while (it.hasNext()) {
						String key = (String) it.next();
						boolean add = false;
						if (key.indexOf("-" + array[i].toLowerCase() + "-") > -1) {
							if (key.length() > key.lastIndexOf("-")+1) {
								String otherWords = key.substring(key.lastIndexOf("-") + 1);
								String[] otherWordsArray = otherWords.split("~");
								StringBuilder tempLine = new StringBuilder();
								for (int k = i+1; k < array.length; k++) {
									if (tempLine.length() > 0) {
										tempLine.append(" ");
									}
									tempLine.append(array[k]);
								}
								int a = 0;
								while (a < otherWordsArray.length) {
									int index = tempLine.toString().toLowerCase().indexOf(otherWordsArray[a].toLowerCase());
									if (index != -1) {
										int lengthIndex = index + otherWordsArray[a].length();
										if ((index == 0 && (tempLine.toString().toLowerCase()
												.indexOf(otherWordsArray[a].toLowerCase() + " ") > -1))
												|| (lengthIndex == tempLine.toString().toLowerCase().length() && (tempLine.toString().toLowerCase()
														.indexOf(" " + otherWordsArray[a].toLowerCase()) > -1))
												|| (tempLine.toString().toLowerCase()
														.indexOf(" " + otherWordsArray[a].toLowerCase() + " ") > -1)) {											
											add = true;
											lastKeyword = wordMatchingMap.get(key);
											lastKeyword = (lastKeyword.indexOf("~") > -1) ? lastKeyword.split("~")[0] : lastKeyword;
											break;
										}
									}									
									a++;
								}
								if (!add) {
									add = true;
									lastKeyword = wordMatchingMap.get(key);
									lastKeyword = (lastKeyword.indexOf("~") > -1) ? lastKeyword.split("~")[1] : lastKeyword;
								}
							} else {
								add = true;
							}							
						} else  if (key.indexOf("~" + array[i].toLowerCase() + "~") > -1) {
							lastKeyword = wordMatchingMap.get(key);
							add = true;
						}
						if (add) {
							if (lastKeyword.equals("LAUNCH") && lineCount >= 2) {
								continue;
							}
							if (notConsiderKeyword.indexOf("~" + lastKeyword + "~") > -1) {
								continue;
							}
							isKeywordMatched = true;
							lastValue = lineBuilder.toString();
							tempKeywordsMap.put(count + "-" + lastKeyword, lastValue);
							previousKeyowrd = lastKeyword;
							j = (j > 0) ? j-1 : j;
							count++;
						}
					}	
				}
			}
		}
		
		if (j > 0 && lastKeyword != null) {
			if (notConsiderKeyword.indexOf("~" + lastKeyword + "~") < 0) {
				tempKeywordsMap.put(count + "-" + lastKeyword, lineBuilder.toString());
				previousKeyowrd = lastKeyword;
				count++;
				j = 0;
			}
		}
	}
	
	private void getData(String[] wordsArray, String keyword, boolean isReverse) {
		if (isReverse) {
			boolean isKeywordCame = false;
			boolean breakFor = false;
			for (int c=wordsArray.length-1; c>=0 && !breakFor; c--) {
				if (wordsArray[c].indexOf("@data@") > -1) {
					dataToStepMap.put(keyword, wordsArray[c]);
					breakFor = true;
					continue;
				} else if (ALL_KEYWORDS.indexOf("~" + wordsArray[c].toLowerCase() + "~") > -1) {
					if (!isKeywordCame)
						isKeywordCame = true;
					else 
						breakFor = true;
					continue;
				}
			}		
		} else {
			boolean breakFor = false;
			for (int c=0; c<wordsArray.length && !breakFor; c++) {
				if (wordsArray[c].indexOf("@data@") > -1) {
					dataToStepMap.put(keyword, wordsArray[c]);
					breakFor = true;
					continue;
				} else if (ALL_KEYWORDS.indexOf("~" + wordsArray[c].toLowerCase() + "~") > -1) {
					breakFor = true;
					continue;
				}				
			}		
		}
	}
	
	private void getLocators(String[] wordsArray, String keyword, boolean isReverse) {
		if (isReverse) {
			boolean isKeywordCame = false;
			boolean breakFor = false;
			for (int c=wordsArray.length-1; c>=0 && !breakFor; c--) {
				if (wordsArray[c].toLowerCase().startsWith("@data@")
						|| (c == wordsArray.length - 1 && wordsArray[c].toLowerCase().equals("and"))) {
					continue;
				}
				if (ALL_KEYWORDS.indexOf("~" + wordsArray[c].toLowerCase() + "~") > -1 || "and".equals(wordsArray[c].toLowerCase())) {
					if (!isKeywordCame) {
						isKeywordCame = true;
						if ("and".equalsIgnoreCase(wordsArray[c])) {
							breakFor = true;
						}
					}
					else 
						breakFor = true;
					continue;
				}
				if (INSIGNIFICANT_WORDS.indexOf("~" + wordsArray[c].toLowerCase() + "~") < 0) {
					if (!locatorMap.containsKey(keyword)) {
						locatorMap.put(keyword, wordsArray[c] + "_");
					} else {
						locatorMap.put(keyword, wordsArray[c] + locatorMap.get(keyword) + "_");
					}
				}												
			}		
		} else {
			boolean breakFor = false;
			for (int c=0; c<wordsArray.length && !breakFor; c++) {
				if ( wordsArray[c].toLowerCase().startsWith("@data@")) {
					continue;
				}
				if (ALL_KEYWORDS.indexOf("~" + wordsArray[c].toLowerCase() + "~") > -1 || "and".equals(wordsArray[c].toLowerCase())) {
					breakFor = true;
					continue;
				}
				if (INSIGNIFICANT_WORDS.indexOf("~" + wordsArray[c].toLowerCase() + "~") < 0) {
					if (!locatorMap.containsKey(keyword)) {
						locatorMap.put(keyword, wordsArray[c] + "_");
					} else {
						locatorMap.put(keyword, locatorMap.get(keyword) + wordsArray[c] + "_");
					}
				}												
			}		
		}
		
		if (locatorMap.get(keyword) == null) {
			populateLocator(wordsArray, keyword, isReverse);
		} 
	}
	
	private void populateLocator(String []wordsArray, String keyword, boolean isReverse) {
		boolean breakFor = false;
		int initial = (isReverse) ? wordsArray.length-1 : 0;
		for (int c = initial; (((isReverse && c>=0) || (!isReverse && c<wordsArray.length)) && !breakFor); c = (isReverse) ? c-1 : c+1) {
			if ( wordsArray[c].toLowerCase().startsWith("@data@")) {
				continue;
			}
			if ("and".equals(wordsArray[c].toLowerCase())) {
				breakFor = true;
				continue;
			}
			if (ALL_KEYWORDS.indexOf("~" + wordsArray[c].toLowerCase() + "~") > -1) {
				locatorMap.put(keyword, wordsArray[c] + "_");
				breakFor = false;
				continue;
			}
			if (INSIGNIFICANT_WORDS.indexOf("~" + wordsArray[c].toLowerCase() + "~") < 0) {
				if (!locatorMap.containsKey(keyword)) {
					locatorMap.put(keyword, wordsArray[c] + "_");
				} else {
					locatorMap.put(keyword, locatorMap.get(keyword) + wordsArray[c] + "_");
				}
			}
		}
	}
	
	private void getLocatorReiterate(String keyword, String inputLinePart) {
		String keyword_count = keyword.split("-")[0];
		int count = Integer.valueOf(keyword_count);
		if (count - 1 >= 0) {
			String lastPartLine = null;
			Iterator<String> it1 = tempKeywordsMap.keySet().iterator();
			while (it1.hasNext()) {
				String key = it1.next();
				if (key.startsWith(String.valueOf(count - 1) + "-")) {
					lastPartLine = tempKeywordsMap.get(key);
					break;
				}
			}							
			if (lastPartLine != null && inputLinePart.length() > lastPartLine.length()) {
				lastPartLine = inputLinePart.substring(inputLinePart.indexOf(lastPartLine) + lastPartLine.length());
				getLocators(lastPartLine.split("\\s+"), keyword, true);
			}
		}		
	}

}
