package com.features;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyReader {
	
	public Properties keyMatchMapWP;
	public Properties wordMatchMapWP;
	public Properties z1Map;
	public Properties s1Map;
	
	public Properties keyMatchMapLP;
	public Properties wordMatchMapLP;
	public Properties z1Map2;
	//public Properties s1Map;
	
	private static PropertyReader propertyReader;
	
	private PropertyReader() throws IOException {
		initWP();
		initLP();
	}
	
	public void initWP() throws IOException {
		keyMatchMapWP = new Properties();
		wordMatchMapWP = new Properties();
		z1Map = new Properties();
		s1Map = new Properties();
		
		InputStream is = PropertyReader.class.getResourceAsStream("keywordMatching-WP.properties");
		keyMatchMapWP.load(is);
		is.close();
		
		is = PropertyReader.class.getResourceAsStream("wordMatching-WP.properties");
		wordMatchMapWP.load(is);
		is.close();
		
		is = PropertyReader.class.getResourceAsStream("z1-WP.properties");
		z1Map.load(is);
		is.close();
		
/*		is = PropertyReader.class.getResourceAsStream("s1-WP.properties");
		s1Map.load(is);
		is.close();*/
	}
	
	public void initLP() throws IOException {
		keyMatchMapLP = new Properties();
		wordMatchMapLP = new Properties();
		s1Map = new Properties();
		z1Map2 = new Properties();
		
		InputStream is = PropertyReader.class.getResourceAsStream("keywordMatching-WP.properties");
		keyMatchMapLP.load(is);
		is.close();
		
		is = PropertyReader.class.getResourceAsStream("wordMatching-WP.properties");
		wordMatchMapLP.load(is);
		is.close();
		
	/*	is = PropertyReader.class.getResourceAsStream("z1-WP2.properties");
		z1Map2.load(is);
		is.close();*/
	}
	
	public static PropertyReader getInstance() throws IOException {
		if (propertyReader == null) {
			propertyReader = new PropertyReader();
		}
		return propertyReader;
	}
	
}
